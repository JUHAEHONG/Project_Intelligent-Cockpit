package eu.opends.camera;

import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.FastMath;
import com.jme3.math.Matrix4f;
import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.renderer.Camera;
import com.jme3.scene.CameraNode;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial.CullHint;
import com.jme3.scene.control.CameraControl;
import com.jme3.scene.control.CameraControl.ControlDirection;
import com.jme3.scene.shape.Cylinder;

import eu.opends.camera.CameraFactory.CameraMode;
import eu.opends.camera.CameraFactory.MirrorMode;
import eu.opends.car.Car;
import eu.opends.car.SteeringCar;
import eu.opends.car.WatchCar;
import eu.opends.drivingTask.settings.SettingsLoader.Setting;
import eu.opends.main.Simulator;
import eu.opends.main.SimulatorWatcher;
import eu.opends.tools.PanelCenter;
import eu.opends.traffic.TrafficCar;

public class WatchCam extends CameraFactory {
	private SteeringCar car;
	private Node carNode;
	private Geometry geoCone;
	private Simulator sim;
	private WatchMode watchMode = WatchMode.LEFT_BACK;

	public WatchCam(SimulatorWatcher sim, SteeringCar car) {
		this.sim = sim;
		this.car = car;
		carNode = car.getCarNode();
		initCamera(sim, carNode);
		setCamMode(CameraMode.EGO);
		initMapMarker();
		setWatchMode(WatchMode.LEFT_BACK);
	}

	private void initMapMarker() {
		Cylinder cone = new Cylinder(10, 10, 3f, 0.1f, 9f, true, false);
		cone.setLineWidth(4f);
		geoCone = new Geometry("TopViewMarker", cone);

		Material coneMaterial = new Material(sim.getAssetManager(),
				"Common/MatDefs/Misc/Unshaded.j3md");
		coneMaterial.setColor("Color", ColorRGBA.Red);
		geoCone.setMaterial(coneMaterial);

		geoCone.setCullHint(CullHint.Always);

		sim.getRootNode().attachChild(geoCone);
	}

	public void setWatchMode(WatchMode mode) {
		this.watchMode = mode;
		switch (watchMode) {
		case RIGHT_BACK:
			/*
			System.out.println("Right");
			camMode = CameraMode.EGO;
			sim.getRootNode().detachChild(mainCameraNode);
			carNode.attachChild(mainCameraNode);
			chaseCam.setEnabled(false);
			setCarVisible(true);
			((CameraControl) mainCameraNode.getChild("CamNode1").getControl(0)).setEnabled(true);
			mainCameraNode.setLocalTranslation(car.getEgoCamPos());
			mainCameraNode.setLocalRotation(new Quaternion().fromAngles(0, 0, 0));
			leftBackViewPort.setEnabled(false);
			rightBackViewPort.setEnabled(true);
			backViewPort.setEnabled(false);
			*/
			
			System.out.println("Right");
			camMode = CameraMode.EGO;
			sim.getRootNode().detachChild(mainCameraNode);
			carNode.attachChild(mainCameraNode);
			chaseCam.setEnabled(false);
			setCarVisible(true);
			((CameraControl) mainCameraNode.getChild("CamNode1").getControl(0)).setEnabled(true);							
			
			
			float horizontalAngle = settingsLoader.getSetting(Setting.General_leftMirror_horizontalAngle, 45f) + 160f;
			float verticalAngle = settingsLoader.getSetting(Setting.General_leftMirror_verticalAngle, -10f);			
			mainCameraNode.setLocalRotation(new Quaternion().fromAngles(verticalAngle*FastMath.DEG_TO_RAD, horizontalAngle*FastMath.DEG_TO_RAD, 0));
			mainCameraNode.setLocalTranslation(car.getEgoCamPos().add(new Vector3f(1, 0, -1)));						
			
			leftBackViewPort.setEnabled(false);
			rightBackViewPort.setEnabled(false);
			backViewPort.setEnabled(false);
			break;

		case LEFT_BACK:/*
			System.out.println("Left");
			camMode = CameraMode.EGO;
			sim.getRootNode().detachChild(mainCameraNode);
			carNode.attachChild(mainCameraNode);
			chaseCam.setEnabled(false);
			setCarVisible(true);
			((CameraControl) mainCameraNode.getChild("CamNode1").getControl(0)).setEnabled(true);
			mainCameraNode.setLocalTranslation(car.getEgoCamPos());
			mainCameraNode.setLocalRotation(new Quaternion().fromAngles(0, 0, 0));			
			leftBackViewPort.setEnabled(true);
			rightBackViewPort.setEnabled(false);
			backViewPort.setEnabled(false);
			*/				
			
			System.out.println("Left");
			camMode = CameraMode.EGO;
			sim.getRootNode().detachChild(mainCameraNode);
			carNode.attachChild(mainCameraNode);
			chaseCam.setEnabled(false);
			setCarVisible(true);
			((CameraControl) mainCameraNode.getChild("CamNode1").getControl(0)).setEnabled(true);						
			
			horizontalAngle = settingsLoader.getSetting(Setting.General_leftMirror_horizontalAngle, -45f) + 200f;
			verticalAngle = settingsLoader.getSetting(Setting.General_leftMirror_verticalAngle, -10f);			
			mainCameraNode.setLocalRotation(new Quaternion().fromAngles(verticalAngle*FastMath.DEG_TO_RAD, horizontalAngle*FastMath.DEG_TO_RAD, 0));
			mainCameraNode.setLocalTranslation(car.getEgoCamPos().add(new Vector3f(-1, 0, -1)));
			
			leftBackViewPort.setEnabled(false);
			rightBackViewPort.setEnabled(false);
			backViewPort.setEnabled(false);
			break;

		case BACK:
			System.out.println("Back");
			camMode = CameraMode.EGO;
			sim.getRootNode().detachChild(mainCameraNode);
			carNode.attachChild(mainCameraNode);
			chaseCam.setEnabled(false);
			setCarVisible(true);
			((CameraControl) mainCameraNode.getChild("CamNode1").getControl(0)).setEnabled(true);						
			
			 horizontalAngle = settingsLoader.getSetting(Setting.General_leftMirror_horizontalAngle, -180f);
			 verticalAngle = settingsLoader.getSetting(Setting.General_leftMirror_verticalAngle, 0f);			
			mainCameraNode.setLocalRotation(new Quaternion().fromAngles(verticalAngle*FastMath.DEG_TO_RAD, horizontalAngle*FastMath.DEG_TO_RAD, 0));
			mainCameraNode.setLocalTranslation(car.getEgoCamPos());
			
			leftBackViewPort.setEnabled(false);
			rightBackViewPort.setEnabled(false);
			backViewPort.setEnabled(false);
			
			/*
			//System.out.println("Back");
			camMode = CameraMode.EGO;
			sim.getRootNode().detachChild(mainCameraNode);
			carNode.attachChild(mainCameraNode);
			chaseCam.setEnabled(false);
			setCarVisible(true);
			((CameraControl) mainCameraNode.getChild("CamNode1").getControl(0)).setEnabled(true);
			mainCameraNode.setLocalTranslation(car.getEgoCamPos());
			mainCameraNode.setLocalRotation(new Quaternion().fromAngles(0, 0, 0));			
			leftBackViewPort.setEnabled(false);
			rightBackViewPort.setEnabled(false);
			backViewPort.setEnabled(true);
*/
			break;
		default:
			break;
		}
	}

	public void changeCamera() {
		// LEFT BACK --> RIGHT_BACK --> BACK
		switch (watchMode) {
		case LEFT_BACK:
			setWatchMode(WatchMode.RIGHT_BACK);
			break;
		case RIGHT_BACK:
			setWatchMode(WatchMode.BACK);
			break;
		case BACK:
			setWatchMode(WatchMode.LEFT_BACK);
			break;
		default:
			setWatchMode(WatchMode.BACK);
			break;
		}
	}

	public void updateCamera(int leftLevel, int rightLevel, int backLevel) {
		if (camMode == CameraMode.EGO) {
			backMirrorFrame.setCullHint(CullHint.Always);
			leftMirrorFrame.setCullHint(CullHint.Always);
			rightMirrorFrame.setCullHint(CullHint.Always);
		} else {
			backViewPort.setEnabled(false);
			leftBackViewPort.setEnabled(false);
			rightBackViewPort.setEnabled(false);

			backMirrorFrame.setCullHint(CullHint.Always);
			leftMirrorFrame.setCullHint(CullHint.Always);
			rightMirrorFrame.setCullHint(CullHint.Always);
		}

		if (camMode == CameraMode.TOP) {
			// camera detached from car node --> update position and rotation
			// separately
			Vector3f targetPosition = carNode.localToWorld(
					new Vector3f(0, 0, 0), null);
			Vector3f camPos = new Vector3f(targetPosition.x,
					targetPosition.y + 30, targetPosition.z);
			mainCameraNode.setLocalTranslation(camPos);

			float upDirection = 0;
			if (isCarPointingUp) {
				float[] angles = new float[3];
				carNode.getLocalRotation().toAngles(angles);
				upDirection = angles[1];
			}
			mainCameraNode.setLocalRotation(new Quaternion().fromAngles(
					-FastMath.HALF_PI, upDirection, 0));
		}

		if (camMode == CameraMode.OUTSIDE) {
			// camera detached from car node --> update position and rotation
			// separately
			mainCameraNode.setLocalTranslation(outsideCamPos);

			Vector3f carPos = carNode.getWorldTranslation();

			Vector3f direction = carPos.subtract(outsideCamPos);
			direction.normalizeLocal();
			direction.negateLocal();

			Vector3f up = new Vector3f(0, 1, 0);

			Vector3f left = up.cross(direction);
			left.normalizeLocal();

			if (left.equals(Vector3f.ZERO)) {
				if (direction.x != 0) {
					left.set(direction.y, -direction.x, 0f);
				} else {
					left.set(0f, direction.z, -direction.y);
				}
			}
			up.set(direction).crossLocal(left).normalizeLocal();
			mainCameraNode.setLocalRotation(new Quaternion().fromAxes(left, up,
					direction));

		}

		// additional top view window ("map")
		if (topViewEnabled) {
			topViewPort.setEnabled(true);
			topViewFrame.setCullHint(CullHint.Dynamic);
			geoCone.setCullHint(CullHint.Dynamic);

			// camera detached from car node --> update position and rotation
			// separately
			float upDirection = 0;
			float addLeft = 0;
			float addRight = 0;
			if (isCarPointingUp) {
				float[] angles = new float[3];
				carNode.getLocalRotation().toAngles(angles);
				upDirection = angles[1] + FastMath.PI;

				// allow to place car in lower part of map (instead of center)
				addLeft = topViewcarOffset * FastMath.sin(upDirection);
				addRight = topViewcarOffset * FastMath.cos(upDirection);
			}
			Quaternion camRot = new Quaternion().fromAngles(FastMath.HALF_PI,
					upDirection, 0);
			topViewCamNode.setLocalRotation(camRot);
			topViewCamNode.detachChildNamed("TopViewMarker");

			Vector3f targetPosition = carNode.localToWorld(
					new Vector3f(0, 0, 0), null);
			float left = targetPosition.x + addLeft;
			float up = targetPosition.y + topViewVerticalDistance;
			float ahead = targetPosition.z + addRight;
			Vector3f camPos = new Vector3f(left, up, ahead);
			topViewCamNode.setLocalTranslation(camPos);

			// set cone position
			geoCone.setLocalTranslation(targetPosition.x, targetPosition.y + 3,
					targetPosition.z);
			geoCone.setLocalRotation(carNode.getLocalRotation());
		} else {
			topViewPort.setEnabled(false);
			topViewFrame.setCullHint(CullHint.Always);
			geoCone.setCullHint(CullHint.Always);
		}
	}

	public void setCarVisible(boolean setVisible) {
		if (setVisible) {
			if (carNode.getCullHint() == CullHint.Always)
				carNode.setCullHint(CullHint.Dynamic);
		} else {
			if (carNode.getCullHint() != CullHint.Always)
				carNode.setCullHint(CullHint.Always);
		}

		PanelCenter.showHood(!setVisible);
	}

	@Override
	public void updateCamera() {
		if (this.car == null)
			return;
		Vector3f mycarPos = car.getPosition();
		// MyLogging(car.getCarNode().getName(), mycarPos);
		float distance = 100.0f;
		int leftLevel = 5;
		int rightLevel = 5;
		int backLevel = 5;

		for (TrafficCar trafficCar : sim.getPhysicalTraffic().getVehicleList()) {
			Vector3f trafficPos = trafficCar.getPosition();
			if (Math.abs(mycarPos.distance(trafficPos)) < distance) {

				// �� �� ��������, �� �� ��ġ�� ���̰��� ���Ѵ�. (Radian to Degree)
				Vector3f myCarDirect = mycarPos.subtract(this.mainCameraNode
						.getWorldTranslation());
				myCarDirect.y = 0;
				myCarDirect.normalizeLocal();

				Vector3f trafficCarDirect = trafficPos
						.subtract(this.mainCameraNode.getWorldTranslation());

				trafficCarDirect.y = 0;
				trafficCarDirect.normalizeLocal();

				float angle = (myCarDirect.angleBetween(trafficCarDirect)) * 180.0f / 3.14f;
				int depthLevel = (int) (mycarPos.distance(trafficPos) / (distance / 4)) + 1;

				/*
				 * �� �� ��ġ �������� �ĸ鿡 ��ġ�� ���
				 */
				if (angle > 90) {
					if (backLevel > depthLevel) {
						backLevel = depthLevel;
					}
				}

				boolean isLeft = (myCarDirect.z * trafficCarDirect.x > myCarDirect.x
						* trafficCarDirect.z);

				/*
				 * �� �� ��ġ �������� �����ʿ� ��ġ�� ���
				 */
				if (angle > 60 && angle < 170 && isLeft == false) {

					if (rightLevel > depthLevel) {
						rightLevel = depthLevel;
					}
				}

				/*
				 * �� �� ��ġ �������� ���ʿ� ��ġ�� ���
				 */
				if (angle > 60 && angle < 170 && isLeft) {
					if (leftLevel > depthLevel) {
						leftLevel = depthLevel;
					}
				}

			}
		}
		this.updateCamera(leftLevel, rightLevel, backLevel);

	}

	@Override
	public void setCamMode(CameraMode mode) {
		// TODO Auto-generated method stub
		mode = CameraMode.EGO;
		this.setWatchMode(watchMode);
	}
}
