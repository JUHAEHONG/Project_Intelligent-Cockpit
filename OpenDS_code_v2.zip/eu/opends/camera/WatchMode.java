package eu.opends.camera;

public enum WatchMode 
{
	LEFT_BACK, RIGHT_BACK, BACK
}
