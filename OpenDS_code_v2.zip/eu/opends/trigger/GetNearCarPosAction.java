package eu.opends.trigger;

import java.util.ArrayList;

import com.jme3.math.Vector3f;

import eu.opends.car.Car;
import eu.opends.main.Simulator;
import eu.opends.tools.PanelCenter;
import eu.opends.tools.SpeedControlCenter;
import eu.opends.traffic.TrafficCar;
import eu.opends.traffic.TrafficCarData;

public class GetNearCarPosAction extends TriggerAction {

	private Simulator sim;
	private int distance;
	public GetNearCarPosAction(float delay, int maxRepeat, Simulator sim, int distance) {
		super(delay, maxRepeat);

		this.sim = sim;
		this.distance = distance;
	}

	@Override
	protected void execute() 
	{
		if(!isExceeded())
		{
			Car car = sim.getCar();
			ArrayList<TrafficCar> trafficCars = 
					sim.getPhysicalTraffic().getVehicleList();
			String message="";
			
			Vector3f carPos = car.getPosition();
			for(TrafficCar trafficCar: trafficCars){
				Vector3f trafficPos = trafficCar.getPosition();
				if(Math.abs(trafficPos.distance(carPos)) < distance){
					message = message + String.format("%s : (%f, %f, %f) distnace - %f \n", trafficCar.getName(), trafficPos.x, trafficPos.y, trafficPos.z, Math.abs(trafficPos.distance(carPos)) );
					
				}				
			}
			
			PanelCenter.getMessageBox().addMessage(message, 1000);
			updateCounter();		
		}
	}
}
