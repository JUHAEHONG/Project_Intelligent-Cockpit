package eu.opends.trigger;

import java.util.ArrayList;

import com.jme3.math.Vector3f;

import eu.opends.car.Car;
import eu.opends.main.Simulator;
import eu.opends.tools.PanelCenter;
import eu.opends.traffic.TrafficCar;

public class LeftLaneChangeAction extends TriggerAction {
	private Simulator sim;

	public LeftLaneChangeAction(float delay, int maxRepeat, Simulator sim) {
		super(delay, maxRepeat);

		this.sim = sim;

	}

	@Override
	protected void execute() {
		if (!isExceeded()) {
			
			/*
			 * �켱 �� �տ� �ִ� ���� ����� ���� ã�´�.
			 */
			Car car = sim.getCar();
			ArrayList<TrafficCar> trafficCars = sim.getPhysicalTraffic()
					.getVehicleList();
			String message = "";			
			Vector3f carPos = car.getPosition();
			float maxDistance = 10000.0f;
			TrafficCar targetCar = null;
			for (TrafficCar trafficCar : trafficCars) {
				Vector3f trafficPos = trafficCar.getPosition();
				float distance = trafficPos.distance(carPos);

				if (distance > 0 && distance < maxDistance) {
					maxDistance = distance;
					targetCar = trafficCar;
				}
			}
			
			if(targetCar!=null){												
				PanelCenter.getMessageBox().addMessage("go left lane.", 1000);
				targetCar.decreaseLane();								
			}

			PanelCenter.getMessageBox().addMessage(message, 1000);
			updateCounter();
		}
	}
}
