package eu.opends.car;

import com.jme3.math.ColorRGBA;

import eu.opends.basics.SimulationBasics;
import eu.opends.drivingTask.DrivingTask;
import eu.opends.drivingTask.scenario.ScenarioLoader;
import eu.opends.drivingTask.scenario.ScenarioLoader.CarProperty;
import eu.opends.main.SimulationDefaults;
import eu.opends.main.Simulator;
import eu.opends.main.SimulatorWatcher;
import eu.opends.trafficObjectLocator.TrafficObjectLocator;

public class WatchCar extends Car {

	 private TrafficObjectLocator trafficObjectLocator;    
	    
		public WatchCar(SimulatorWatcher sim) 
		{		
			this.sim = sim;
			
			DrivingTask drivingTask = SimulationBasics.getDrivingTask();
			ScenarioLoader scenarioLoader = drivingTask.getScenarioLoader();
			
			initialPosition = scenarioLoader.getStartLocation();
			if(initialPosition == null)
				initialPosition = SimulationDefaults.initialCarPosition;
			
			this.initialRotation = scenarioLoader.getStartRotation();
			if(this.initialRotation == null)
				this.initialRotation = SimulationDefaults.initialCarRotation;
			
			/*
			// add start position as reset position
			Simulator.getResetPositionList().add(new ResetPosition(initialPosition,initialRotation));
			
			mass = scenarioLoader.getChassisMass();
			
			minSpeed = scenarioLoader.getCarProperty(CarProperty.engine_minSpeed, SimulationDefaults.engine_minSpeed);
			maxSpeed = scenarioLoader.getCarProperty(CarProperty.engine_maxSpeed, SimulationDefaults.engine_maxSpeed);
				
			decelerationBrake = scenarioLoader.getCarProperty(CarProperty.brake_decelerationBrake, 
					SimulationDefaults.brake_decelerationBrake);
			maxBrakeForce = 0.004375f * decelerationBrake * mass;
			
			decelerationFreeWheel = scenarioLoader.getCarProperty(CarProperty.brake_decelerationFreeWheel, 
					SimulationDefaults.brake_decelerationFreeWheel);
			maxFreeWheelBrakeForce = 0.004375f * decelerationFreeWheel * mass;
			
			engineOn = scenarioLoader.getCarProperty(CarProperty.engine_engineOn, SimulationDefaults.engine_engineOn);
			showEngineStatusMessage(engineOn);
			
			Float lightIntensityObj = scenarioLoader.getCarProperty(CarProperty.light_intensity, SimulationDefaults.light_intensity);
			if(lightIntensityObj != null)
				lightIntensity = lightIntensityObj;
			
			transmission = new Transmission(this);
			powerTrain = new PowerTrain(this);
			
			modelPath = scenarioLoader.getModelPath();
			
			init();

	        // allows to place objects at current position
	        trafficObjectLocator = new TrafficObjectLocator(sim, this);
	        */
	    }

		
		public TrafficObjectLocator getObjectLocator()
		{
			return trafficObjectLocator;
		}
		
		
		// will be called, in every frame
		public void update(float tpf)
		{
	        
		}
}
