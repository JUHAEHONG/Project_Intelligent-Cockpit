package eu.opends.main;

import java.io.File;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.jme3.app.StatsAppState;
import com.jme3.app.state.VideoRecorderAppState;
import com.jme3.input.Joystick;
import com.jme3.math.Vector3f;
import com.jme3.niftygui.NiftyJmeDisplay;
import com.jme3.scene.Node;
import com.jme3.system.AppSettings;

import de.lessvoid.nifty.Nifty;
import eu.opends.analyzer.DataWriter;
import eu.opends.analyzer.DrivingTaskLogger;
import eu.opends.audio.AudioCenter;
import eu.opends.basics.InternalMapProcessing;
import eu.opends.basics.SimulationBasics;
import eu.opends.camera.SimulatorCam;
import eu.opends.camera.WatchCam;
import eu.opends.cameraFlight.CameraFlight;
import eu.opends.cameraFlight.NotEnoughWaypointsException;
import eu.opends.canbus.CANClient;
import eu.opends.car.Car;
import eu.opends.car.ResetPosition;
import eu.opends.car.SteeringCar;
import eu.opends.car.WatchCar;
import eu.opends.drivingTask.DrivingTask;
import eu.opends.drivingTask.settings.SettingsLoader.Setting;
import eu.opends.effects.EffectCenter;
import eu.opends.environment.TrafficLightCenter;
import eu.opends.eyetracker.EyetrackerCenter;
import eu.opends.input.KeyBindingCenter;
import eu.opends.knowledgeBase.KnowledgeBase;
import eu.opends.multiDriver.MultiDriverClient;
import eu.opends.multiDriver.MultiDriverWatcherClient;
import eu.opends.niftyGui.DrivingTaskSelectionGUIController;
import eu.opends.reactionCenter.ReactionCenter;
import eu.opends.settingsController.SettingsControllerServer;
import eu.opends.taskDescription.contreTask.SteeringTask;
import eu.opends.taskDescription.tvpTask.ThreeVehiclePlatoonTask;
import eu.opends.tools.CollisionListener;
import eu.opends.tools.ObjectManipulationCenter;
import eu.opends.tools.PanelCenter;
import eu.opends.tools.SpeedControlCenter;
import eu.opends.tools.Util;
import eu.opends.traffic.PhysicalTraffic;
import eu.opends.trigger.TriggerCenter;
import eu.opends.visualization.LightningClient;

public class SimulatorWatcher extends Simulator {
	// SimulationBasics�� Simulator�� �ʿ��� �⺻���� ��ҵ��� ������ �ش�.
	// ���� ������ ���õ� �κе��� �� �ִ�.

	private final static Logger logger = Logger.getLogger(Simulator.class);

	// Java OpenGL GUI OpenSource
	private Nifty nifty;

	private boolean drivingTaskGiven = false;
	private boolean initializationFinished = false;

	/*
	 * ���⼭ ���ʹ� �ùķ��̼� ȯ��� ���õ� ��ü���� ����ǰ� �ִ�. ������� �����ϴ� ��, �� �ֺ��� Ʈ���� ȯ��, �߷��̳� ����,
	 * �׿� CANInterface�� ���� �ܺ� ��ҵ��� �Ʒ� ����Ǿ� �ִ�.
	 */
	private static String driverName;

	private static Float gravityConstant;

	public static Float getGravityConstant() {
		return gravityConstant;
	}

	private SteeringCar car;

	public SteeringCar getCar() {
		return car;
	}

	private static DrivingTaskLogger drivingTaskLogger;

	private PhysicalTraffic physicalTraffic;

	public PhysicalTraffic getPhysicalTraffic() {
		return physicalTraffic;
	}

	private MultiDriverWatcherClient multiDriverClient;

	public MultiDriverWatcherClient getMultiDriverClient() {
		return multiDriverClient;
	}

	public static DrivingTaskLogger getDrivingTaskLogger() {
		return drivingTaskLogger;
	}

	private boolean dataWriterQuittable = false;
	private DataWriter dataWriter;

	public DataWriter getMyDataWriter() {
		return dataWriter;
	}

	private LightningClient lightningClient;

	public LightningClient getLightningClient() {
		return lightningClient;
	}

	private static CANClient canClient;

	public static CANClient getCanClient() {
		return canClient;
	}

	private TriggerCenter triggerCenter = new TriggerCenter(this);

	public TriggerCenter getTriggerCenter() {
		return triggerCenter;
	}

	private static List<ResetPosition> resetPositionList = new LinkedList<ResetPosition>();

	public static List<ResetPosition> getResetPositionList() {
		return resetPositionList;
	}

	private boolean showStats = false;

	public void showStats(boolean show) {
		showStats = show;
		setDisplayFps(show);
		setDisplayStatView(show);
	}

	public void toggleStats() {
		showStats = !showStats;
		showStats(showStats);
	}

	private CameraFlight cameraFlight;

	public CameraFlight getCameraFlight() {
		return cameraFlight;
	}

	private SteeringTask steeringTask;

	public SteeringTask getSteeringTask() {
		return steeringTask;
	}

	private ThreeVehiclePlatoonTask threeVehiclePlatoonTask;

	public ThreeVehiclePlatoonTask getThreeVehiclePlatoonTask() {
		return threeVehiclePlatoonTask;
	}

	private ReactionCenter reactionCenter;

	public ReactionCenter getReactionCenter() {
		return reactionCenter;
	}

	private EffectCenter effectCenter;

	public EffectCenter getEffectCenter() {
		return effectCenter;
	}

	private ObjectManipulationCenter objectManipulationCenter;

	public ObjectManipulationCenter getObjectManipulationCenter() {
		return objectManipulationCenter;
	}

	private String instructionScreenID = null;

	public void setInstructionScreen(String ID) {
		instructionScreenID = ID;
	}

	private SettingsControllerServer settingsControllerServer;

	public SettingsControllerServer getSettingsControllerServer() {
		return settingsControllerServer;
	}

	private EyetrackerCenter eyetrackerCenter;

	public EyetrackerCenter getEyetrackerCenter() {
		return eyetrackerCenter;
	}

	private static String outputFolder;

	public static String getOutputFolder() {
		return outputFolder;
	}

	/*
	 * �Ƹ� ���� ���� ���� �� ���õ� �κ�
	 */

	/*
	 * JME3 ���ø����̼��� ����� �� ó���� �ѹ� ������ �ǰ� �Ǵµ� ���⿡ ���̶�簡 ī�޶� �� ��Ÿ �ʱ�ȭ �¾��� �� �� �ַ�
	 * ����մϴ�. ���⼭��, �ùķ��̼� ����� �ʿ��� ����(scenario xml�̳� scene.xml�� ���� ��), �����̳� �� ��
	 * ����, ���뷮 ����, ��ȣ�� �� �⺻���� �κ��� ���⼭ �ʱ�ȭ ���ݴϴ�.
	 */
	@Override
	public void simpleInitApp() {
		showStats(false);

		if (drivingTaskGiven)
			simpleInitDrivingTask(SimulationDefaults.drivingTaskFileName,
					SimulationDefaults.driverName);
		else
			initDrivingTaskSelectionGUI();
	}

	private void initDrivingTaskSelectionGUI() {
		NiftyJmeDisplay niftyDisplay = new NiftyJmeDisplay(assetManager,
				inputManager, audioRenderer, guiViewPort);

		// Create a new NiftyGUI object
		nifty = niftyDisplay.getNifty();

		String xmlPath = "Interface/DrivingTaskSelectionGUI.xml";

		// Read XML and initialize custom ScreenController
		nifty.fromXml(xmlPath, "start", new DrivingTaskSelectionGUIController(
				this, nifty));

		// attach the Nifty display to the gui view port as a processor
		guiViewPort.addProcessor(niftyDisplay);

		// disable fly cam
		flyCam.setEnabled(false);
	}

	public void closeDrivingTaskSelectionGUI() {
		nifty.exit();
		inputManager.setCursorVisible(false);
		flyCam.setEnabled(true);
	}

	/*
	 * ������ �ùķ��̼� �� ������ �����Ͽ��ٸ� �� �޼ҵ尡 ����
	 */
	public void simpleInitDrivingTask(String drivingTaskFileName,
			String driverName) {
		SimulationDefaults.drivingTaskFileName = drivingTaskFileName;

		initDrivingTaskLayers();

		showStats(false);
		PanelCenter.init(this);
		

		if (driverName == null || driverName.isEmpty())
			driverName = settingsLoader.getSetting(Setting.General_driverName,
					SimulationDefaults.driverName);
		
		driverName ="watcher";

		// open TCP connection to Multi Driver
		if (settingsLoader.getSetting(Setting.MultiDriver_enableConnection,
				SimulationDefaults.MultiDriver_enableConnection)) {
			multiDriverClient = new MultiDriverWatcherClient(this, driverName);
			multiDriverClient.start();
		} else {
			System.exit(0);
		}

		initializationFinished = true;
	}

	private void initDrivingTaskLayers() {
		String drivingTaskFileName = SimulationDefaults.drivingTaskFileName;
		File drivingTaskFile = new File(drivingTaskFileName);
		drivingTask = new DrivingTask(this, drivingTaskFile);

		sceneLoader = drivingTask.getSceneLoader();
		scenarioLoader = drivingTask.getScenarioLoader();
		interactionLoader = drivingTask.getInteractionLoader();
		settingsLoader = drivingTask.getSettingsLoader();
	}

	/*
	 * ������ �ʱ�ȭ�� �� �Ǿ��ٸ�, ���� �ֱ������� �Ʒ��� �޼ҵ尡 ����ȴ�. ���� ���������� �ֱ������� �������� ��ü�� ������ ������Ʈ
	 * �� �ʿ䰡 �ִ�. ������� �ڵ����� �ʴ� 3cm�� �����̴� ���� �ε巴�� ���̰� �Ϸ���, �ּ��� 30ms�� 1mm�� �������� �Ѵ�.
	 * �� ��� �뷫 30 ������ ������ ������ �����̴�.
	 */

	boolean watcherInitFinish = false;

	@Override
	public void simpleUpdate(float tpf) {

		if (initializationFinished && watcherInitFinish == false) {
			if (multiDriverClient != null)
				multiDriverClient.update();

			if (multiDriverClient.getID() != null) {
				super.initOnce();

				gravityConstant = drivingTask.getSceneLoader().getGravity(
						SimulationDefaults.gravity);

				getPhysicsSpace().setGravity(
						new Vector3f(0, -gravityConstant, 0));
				// getPhysicsSpace().setAccuracy(0.005f);

				InternalMapProcessing pp = new InternalMapProcessing(this);

				car = new SteeringCar(this);

				physicalTraffic = new PhysicalTraffic(this);
				while (multiDriverClient.getID() == null) {
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
					}
				}

				cameraFactory = new WatchCam(this, car);
				effectCenter = new EffectCenter(this);

				// setup key binding
				keyBindingCenter = new KeyBindingCenter(this);

				// start trafficLightCenter
				trafficLightCenter = new TrafficLightCenter(this);

				// init trigger center
				triggerCenter.setup();

				SpeedControlCenter.init(this);

				try {
					// attach camera to camera flight
					cameraFlight = new CameraFlight(this);
				} catch (NotEnoughWaypointsException e) {
					// follower.attachChild(cameraFactory.getMainCameraNode());
					this.getCar().getCarNode()
							.attachChild(cameraFactory.getMainCameraNode());
					// if not enough way points available, attach camera to
					// driving car
					// follower.getCarNode()
					// .attachChild(cameraFactory.getMainCameraNode());
				}

				reactionCenter = new ReactionCenter(this);

				steeringTask = new SteeringTask(this, driverName);

				threeVehiclePlatoonTask = new ThreeVehiclePlatoonTask(this,
						driverName);

				objectManipulationCenter = new ObjectManipulationCenter(this);

				StatsAppState statsAppState = stateManager
						.getState(StatsAppState.class);
				if (statsAppState != null && statsAppState.getFpsText() != null
						&& statsAppState.getStatsView() != null) {
					statsAppState.getFpsText().setLocalTranslation(3,
							getSettings().getHeight() - 145, 0);
					statsAppState.getStatsView().setLocalTranslation(3,
							getSettings().getHeight() - 145, 0);
					statsAppState.setDarkenBehind(false);
				}

				// add physics collision listener
				CollisionListener collisionListener = new CollisionListener();
				getPhysicsSpace().addCollisionListener(collisionListener);
				watcherInitFinish = true;
			}

			// watcherInitFinish = true;
			// }
		}

		if (initializationFinished && watcherInitFinish) {
			//super.simpleUpdate(tpf);
			// updates camera

			// PanelCenter.update();

			// triggerCenter.doTriggerChecks();
			
			cameraFactory.updateCamera();			

			if (multiDriverClient != null)
				multiDriverClient.update();			

			physicalTraffic.update();

			// TODO start thread in init-method to update traffic
			// SpeedControlCenter.update();

			// update necessary even in pause
			// AudioCenter.update(tpf, cam);

			//if (!isPause())
				//steeringTask.update(tpf);

			// if (!isPause())
			// getCameraFlight().play();

			// threeVehiclePlatoonTask.update(tpf);

			// if (cameraFlight != null)
			// cameraFlight.update();

			// reactionCenter.update();

			// update effects
			// effectCenter.update(tpf);

			// forward instruction screen if available
			// if (instructionScreenID != null) {
			// instructionScreenGUI.showDialog(instructionScreenID);
			// instructionScreenID = null;
			// }

			// if (eyetrackerCenter != null)
			// eyetrackerCenter.update();
		}
	}

	/**
	 * Cleanup after game loop was left. Will be called when pressing any
	 * close-button. destroy() will be called subsequently.
	 */
	/*
	 * @Override public void stop() { logger.info("started stop()");
	 * super.stop(); logger.info("finished stop()"); }
	 */

	/**
	 * Cleanup after game loop was left Will be called whenever application is
	 * closed.
	 */

	@Override
	public void destroy() {
		logger.info("started destroy()");

		if (initializationFinished) {

			if (multiDriverClient != null)
				multiDriverClient.close();

			// trafficLightCenter.close();

			// steeringTask.close();

			// threeVehiclePlatoonTask.close();

			// reactionCenter.close();

			// KnowledgeBase.KB.disconnect();

			// car.close();

			physicalTraffic.close();

			if (settingsControllerServer != null)
				settingsControllerServer.close();

			if (eyetrackerCenter != null)
				eyetrackerCenter.close();

			// initDrivingTaskSelectionGUI();
		}

		super.destroy();
		logger.info("finished destroy()");
		System.exit(0);
	}

	public static void main(String[] args) {
		try {
			// load logger configuration file
			PropertyConfigurator
					.configure("assets/JasperReports/log4j/log4j.properties");

			/*
			 * logger.debug("Sample debug message");
			 * logger.info("Sample info message");
			 * logger.warn("Sample warn message");
			 * logger.error("Sample error message");
			 * logger.fatal("Sample fatal message");
			 */

			// only show severe jme3-logs
			java.util.logging.Logger.getLogger("").setLevel(
					java.util.logging.Level.SEVERE);

			SimulatorWatcher sim = new SimulatorWatcher();

			if (args.length >= 1) {
				if (DrivingTask.isValidDrivingTask(new File(args[0]))) {
					SimulationDefaults.drivingTaskFileName = args[0];
					sim.drivingTaskGiven = true;
				}
			}

			if (args.length >= 2) {
				SimulationDefaults.driverName = args[1];
			}

			AppSettings settings = new AppSettings(false);
			settings.setUseJoysticks(true);
			settings.setSettingsDialogImage("OpenDS.png");
			settings.setTitle("OpenDS");

			// set splash screen parameters
			/*
			 * settings.setFullscreen(false); settings.setResolution(1280, 720);
			 * settings.setSamples(4); settings.setBitsPerPixel(24);
			 * settings.setVSync(false); settings.setFrequency(60);
			 */

			sim.setSettings(settings);

			// TODO show/hide splash screen
			// sim.setShowSettings(false);

			sim.setPauseOnLostFocus(false);

			sim.start();
		} catch (Exception e1) {
			logger.fatal("Could not run main method:", e1);
		}
	}
}
