package eu.opends.main;

import com.jme3.math.Vector3f;

import eu.opends.car.Car;
import eu.opends.traffic.TrafficCar;

public class CarPositionThread extends Thread {

	Simulator sim;

	public CarPositionThread(Simulator sim) {
		this.sim = sim;
	}

	@Override
	public void run() {
		try {

			Car car = sim.getCar();
			Vector3f mycarPos = car.getPosition();
			MyLogging(car.getCarNode().getName(), mycarPos);
			float distance = 100.0f;

			for (TrafficCar trafficCar : sim.getPhysicalTraffic()
					.getVehicleList()) {

				Vector3f trafficPos = trafficCar.getPosition();
				if (Math.abs(mycarPos.distance(trafficPos)) < distance) {

					MyLogging(trafficCar.getName(), trafficPos);
				}

			}

			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	private void MyLogging(String carName, Vector3f trafficPos) {
		sim.getDrivingTaskLogger().reportText(
				String.format("%s - %f %f %f", carName, trafficPos.x,
						trafficPos.y, trafficPos.z));
	}

}
