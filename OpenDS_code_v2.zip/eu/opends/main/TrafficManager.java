package eu.opends.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.jfree.util.Log;

import com.jme3.math.Vector3f;

import eu.opends.car.Car;
import eu.opends.traffic.FollowBoxSettings;
import eu.opends.traffic.PhysicalTraffic;
import eu.opends.traffic.TrafficCar;
import eu.opends.traffic.TrafficCarData;
import eu.opends.traffic.Waypoint;

public class TrafficManager {
	// /ArrayList<TrafficCar> trafficCars = new ArrayList<TrafficCar>();
	int carNum = 100;
	//�ʹ� �ڿ� �ְų�, �տ� �ִ� ���� �����Ѵ�.
	float back_distance = -200;
	float distance = 600;
	Simulator sim = null;
	int prevLane = -1;

	Random random;

	public TrafficManager(Simulator sim, int carNum, float distance) {
		this.sim = sim;
		this.carNum = carNum;
		this.distance = distance;
		random = new Random();
		initCarList();
	}

	ArrayList<TrafficCarData> carList = new ArrayList<TrafficCarData>();

	public void initCarList() {

		carList.add(new TrafficCarData("PurpleMitsubishi-sample", 800, 3.3f,
				8.7f, 2.0f, true,
				"Models/Cars/drivingCars/PurpleMitsubishi/Car.scene", null));

		carList.add(new TrafficCarData("ferrari-sample", 800, 3.3f, 8.7f, 2.0f,
				true, "Models/Cars/drivingCars/Ferrari/Car.scene",
				null));		
		
		carList.add(new TrafficCarData("Chevy-sample", 800, 3.3f, 8.7f, 2.0f,
				true, "Models/Cars/drivingCars/Chevy/Car.scene",
				null));

	}

	int count = 0;

	public void update() {
		count++;

		if (count >= 200) {
			Car myCar = this.sim.getCar();
			ArrayList<TrafficCar> cars = this.sim.getPhysicalTraffic()
					.getVehicleList();
			cleanup(myCar, cars);

			if (cars.size() < carNum) {
				initNewcar(myCar, carNum - cars.size(), 0);
			}
		}

		count = count % 200;

	}

	int carIndex = 0;

	public void initNewcar(Car myCar, int i, int offset) {
		Vector3f myPos = myCar.getPosition();

		int drivingLane = random.nextInt(5);
		// �������̸� ������ ���õ� ������ �ߺ��ؼ� ���� �������� �ʴ´�.
		if(drivingLane == prevLane){
			drivingLane = (drivingLane + 1) % 5;			
		}
		prevLane = drivingLane;
		
		int zOffset = random.nextInt(10) -5 * 100;

		float xPos =0;// (drivingLane - 2) * 3.7f ;
		float yPos = 0;
		
		if (zOffset <= 0) {
			zOffset = zOffset - 100;
		} else {
			zOffset = zOffset + 100;
		}
		float zPos = myPos.z + zOffset + offset;

		Vector3f newCarPos = new Vector3f(xPos, yPos, zPos);
		String carName = String.format("trafficCar-%d", carIndex);
		carIndex++;

		int speed = random.nextInt(60) + 20;
		//Vector3f newCarDest = new Vector3f(newCarPos.x, 0, -25000);
		ArrayList<Waypoint> newWayPoint = new ArrayList<Waypoint>();
		newWayPoint.add(new Waypoint(carName + "waypoint1", newCarPos, speed, "",
				0.3f, ""));
		/*
		Vector3f newCarDest = new Vector3f(newCarPos.x, 0, -25000);
		newWayPoint.add(new Waypoint(carName + String.format("waypoint%05d", 2), newCarDest, speed, "",
				0.3f, ""));
		*/
		for(int x=0;x<2000;x++){
			Vector3f newCarDest = new Vector3f(newCarPos.x, 0, zPos + (-25 * x));
			newWayPoint.add(new Waypoint(carName + String.format("waypoint%05d", x), newCarDest, speed, "",
					0.3f, ""));			
		}
		
		
		FollowBoxSettings newCarWayPoint = new FollowBoxSettings(newWayPoint,
				3.0f, 0.05f, false,false, carName + "waypoint1");
		
		int carType = random.nextInt(carList.size());
		TrafficCarData sampleCarData = carList.get(carType);
		TrafficCarData newCarData = new TrafficCarData(carName,
				sampleCarData.getMass(), sampleCarData.getAcceleration(),
				sampleCarData.getDecelerationBrake(),
				sampleCarData.getDecelerationFreeWheel(), true,
				sampleCarData.getModelPath(), newCarWayPoint);

		TrafficCar newCar = new TrafficCar(sim, newCarData, drivingLane);
		PhysicalTraffic.newCar(newCar);	
	}

	public void cleanup(Car myCar, ArrayList<TrafficCar> cars) {
		ArrayList<TrafficCar> needToDelete = new ArrayList<TrafficCar>();

		for (TrafficCar car : cars) {	
			float dist = myCar.getPosition().distance(car.getPosition());
			//System.out.println(dist);
			if (dist < this.back_distance || dist > this.distance) {		
				
				needToDelete.add(car);
			}
		}
		
		for (TrafficCar car : needToDelete) {				
			PhysicalTraffic.removeCar(car);			
		}

	}

}
